class Micropost < ActiveRecord::Base
end
